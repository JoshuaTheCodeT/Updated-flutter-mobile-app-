
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class Users extends StatefulWidget {
  final String token;
  Users(this.token);

  @override
  _UsersState createState() => _UsersState();
}

class _UsersState extends State<Users> {
  List users = [];

  fetch() async {
    var res = await http.get(
      Uri.parse("http://YOUR_IP/api/get_users.php"),
      headers: {"Authorization": widget.token},
    );
    setState(() {
      users = jsonDecode(res.body);
    });
  }

  deleteUser(id) async {
    await http.post(
      Uri.parse("http://YOUR_IP/api/delete_user.php"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"id": id}),
    );
    fetch();
  }

  @override
  void initState() {
    super.initState();
    fetch();
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: users.length,
      itemBuilder: (context, i) {
        return Card(
          child: ListTile(
            title: Text(users[i]['username']),
            trailing: IconButton(
              icon: Icon(Icons.delete, color: Colors.red),
              onPressed: () => deleteUser(users[i]['id']),
            ),
          ),
        );
      },
    );
  }
}
