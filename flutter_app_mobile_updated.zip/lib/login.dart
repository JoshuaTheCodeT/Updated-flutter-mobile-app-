
import 'package:flutter/material.dart';
import 'dashboard.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController user = TextEditingController();
  TextEditingController pass = TextEditingController();
  bool loading = false;

  login() async {
    setState(() => loading = true);

    var res = await http.post(
      Uri.parse("http://YOUR_IP/api/login.php"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "username": user.text,
        "password": pass.text
      }),
    );

    var data = jsonDecode(res.body);
    setState(() => loading = false);

    if (data["status"] == "success") {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => Dashboard(data["token"]),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(data["message"] ?? "Login failed"))
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("IMS Login", style: TextStyle(fontSize: 24)),
            TextField(controller: user, decoration: InputDecoration(labelText: "Username")),
            TextField(controller: pass, decoration: InputDecoration(labelText: "Password")),
            SizedBox(height: 10),
            loading ? CircularProgressIndicator() :
            ElevatedButton(onPressed: login, child: Text("Login")),
          ],
        ),
      ),
    );
  }
}
